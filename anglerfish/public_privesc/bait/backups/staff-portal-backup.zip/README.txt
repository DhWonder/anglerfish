Example Clinic — staff portal backup (staging)
Date: 2026-10-12
Contents: portal-config.bak (staging creds)
Portal: /portal/login.php
